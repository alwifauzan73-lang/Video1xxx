const menuBtn=document.getElementById('menuBtn');
const navLinks=document.getElementById('navLinks');
menuBtn.addEventListener('click',()=>navLinks.classList.toggle('open'));
document.querySelectorAll('.nav-links a').forEach(a=>a.addEventListener('click',()=>navLinks.classList.remove('open')));

document.getElementById('year').textContent=new Date().getFullYear();

const input=document.getElementById('searchInput');
const articles=[...document.querySelectorAll('.article')];
const noResult=document.getElementById('noResult');

function searchArticles(){
  const q=input.value.toLowerCase().trim();
  let found=0;
  articles.forEach(card=>{
    const match=card.dataset.title.toLowerCase().includes(q);
    card.style.display=match?'block':'none';
    if(match) found++;
  });
  noResult.style.display=found?'none':'block';
}
document.getElementById('searchBtn').addEventListener('click',searchArticles);
input.addEventListener('input',searchArticles);

const modal=document.getElementById('modal');
const modalTitle=document.getElementById('modalTitle');
const modalText=document.getElementById('modalText');

document.querySelectorAll('.readBtn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    const card=btn.closest('.article');
    modalTitle.textContent=card.querySelector('h3').textContent;
    modalText.textContent='Artikel ini merupakan contoh konten Funia Otomotif. Kamu dapat mengganti teks ini dengan artikel lengkap, gambar, video, atau informasi otomotif milikmu sendiri.';
    modal.classList.add('show');
  });
});

document.querySelectorAll('.gallery-item').forEach(item=>{
  item.addEventListener('click',()=>{
    modalTitle.textContent=item.dataset.name;
    modalText.textContent='Galeri: '+item.dataset.name+'. Area ini dapat kamu ganti dengan foto kendaraan asli menggunakan tag <img>.';
    modal.classList.add('show');
  });
});

document.getElementById('closeModal').addEventListener('click',()=>modal.classList.remove('show'));
modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('show')});
document.addEventListener('keydown',e=>{if(e.key==='Escape')modal.classList.remove('show')});
